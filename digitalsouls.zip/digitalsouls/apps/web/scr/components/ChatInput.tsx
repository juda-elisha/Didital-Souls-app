import React, { useState } from 'react';

export function ChatInput({ characterId, onResponse }: { characterId: "Liana"|"Nova"|"Clowie"; onResponse: (reply: string) => void }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("http://localhost:4000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          characterId,
          message: input
        })
      });
      const data = await res.json();
      onResponse(data.response ?? "(No reply)");
    } catch (err) {
      onResponse("Sorry, something went wrong.");
    }
    setInput("");
    setLoading(false);
  }

  return (
    <form onSubmit={sendMessage}>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder={`Say something to ${characterId}...`}
        disabled={loading}
      />
      <button type="submit" disabled={loading || !input.trim()}>Send</button>
    </form>
  );
}